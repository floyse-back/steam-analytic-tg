


images_urls = {
    "news_new_release": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754059938/new_release_ogrmkb.png",
    "news_free_games_now": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754059687/free_dqksps.png",
    "news_event_history": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754061355/history_hygddz.png",
    "news_discounts_steam_now": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754059322/sales_day_flhzwe.png",
    "news_top_for_a_coins": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754061817/game_for_money_qcorat.png",
    "news_random_game": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754060546/random_tzexkj.png",
    "news_calendar_event_now": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754060260/steam_event_bqgpco.png",
}

images_urls_subscribes = {
    "subscribe_steam_news": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754060260/steam_event_bqgpco.png",
    "subscribe_hot_discount_notificate": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754059322/sales_day_flhzwe.png",
    "subscribe_free_games": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754059687/free_dqksps.png",
    "subscribe_new_release": "https://res.cloudinary.com/dgjz5nvuo/image/upload/v1754059938/new_release_ogrmkb.png",
}