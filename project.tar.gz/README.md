# Steam Analytic Telegram Bot
## Steam Analytic Bot - this bot designed from Denys Zagorodnii